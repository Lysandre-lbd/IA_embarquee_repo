/**
  ******************************************************************************
  * @file    model_maintenance_data_params.c
  * @author  AST Embedded Analytics Research Platform
  * @date    2026-03-04T09:15:19+0100
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#include "model_maintenance_data_params.h"


/**  Activations Section  ****************************************************/
ai_handle g_model_maintenance_activations_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(NULL),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};




/**  Weights Section  ********************************************************/
AI_ALIGNED(32)
const ai_u64 s_model_maintenance_weights_array_u64[427] = {
  0x3ebe96e7bc38b476U, 0xbf5a4b14bee2309bU, 0xbb109e523decaf07U, 0x3dd7dd85be9ac68aU,
  0xbd9aff45ba0b7518U, 0x3ed89fbabe57e446U, 0xbe9946c1be1d718fU, 0x3e374bf3be731a2eU,
  0xbde94776be383db9U, 0x3df9c338bc89f615U, 0xbea372fbbd049281U, 0x3ec1031cbf1ad34bU,
  0x3e9c2253be85e100U, 0xbebfc251be5eff41U, 0xbe24e406becc8f39U, 0x3f303941bc8865beU,
  0xbf61df73bef37e76U, 0x3be6e5c3bdb464f8U, 0x3da1de58bcf329d1U, 0xbe89d1f5bcc51160U,
  0x3f19164dbf1543b3U, 0x3e8ec037bc84ad2aU, 0x3f7f3ca1be61133fU, 0x3bd1fff7bd82015eU,
  0xbee593a9bdfad3a2U, 0xbebae5343e6d7ecaU, 0xbe4150fcbed49e77U, 0xbd62d090bd1e58ccU,
  0x3de52f833d2c2395U, 0x3ee45a5d3eed6ddbU, 0x3effb869bc4193edU, 0xbf767885bf326fd9U,
  0xbd61f391befcec0cU, 0xbe4f30bebd23c787U, 0xbe642fccbdd483c2U, 0xbba13661bed2ea29U,
  0x3d7696b33af3e020U, 0xbea5bb5bbcd69950U, 0x3f560385bce2e0a9U, 0x3e9c51e3bc3b2879U,
  0xbe55f5b6bdc26309U, 0xbeace1eebec182a6U, 0x3d745caabc9bb0b7U, 0x3f87b8e5bc9d6fd3U,
  0xbd5a86233f1d1851U, 0x3f2c7e2c3c230011U, 0xbf3ada19bed0c85bU, 0xbb075348bdc0ad94U,
  0xbe417b7fbc0387feU, 0x3f3251273f17ea06U, 0xbe4c46403cfe0799U, 0xbd129e9a3b2b7279U,
  0xbc6aca5e3c6a0e71U, 0x3f4fba813d8adcc5U, 0xbe9b1b4d3dc4962bU, 0xbf68af2f3e4fd14eU,
  0xbb4e0f49bf0bb31dU, 0xbd6a949c3e261122U, 0xbf019df23da80c1bU, 0xbe25a0cbbf1c5ae7U,
  0xbca5bca7bd0d07ddU, 0x3d25303a3eaf317eU, 0x3f2bbf51bc5b599dU, 0x3e8c136dbb907e76U,
  0xbf1c7083bd03b5cbU, 0x3f1ff313bea0c576U, 0xbee542ae3dee6826U, 0x3f2cf8cd3e5bc4f6U,
  0xbe3b54fa3f14feceU, 0xbe8fa1493deebae4U, 0x3ea9b9fdbf0eb90bU, 0xbef36ea6bdca7f19U,
  0xbe5eb7fe39ab56e0U, 0xbf8630053e75d514U, 0x3e042a8bbf168d4eU, 0x3e202ed53d28f19bU,
  0x3f0f8b06bf364cfdU, 0xbecee4fc3e230a21U, 0xbd6828d9bd202b32U, 0xbd1bddc03d6003beU,
  0x3f6e434f3c2aedadU, 0xbdc79822bcea16edU, 0x3f53cf923cf0f060U, 0xbd30e2413f351259U,
  0x3cbaee0b3d089421U, 0x3f685ab8bcc5f480U, 0xbd234fea3f6a072cU, 0xbefea15b3e773152U,
  0xbea2afd23eb49faaU, 0xbe064a02beb4eee1U, 0xbe8c0829bd9ba5e8U, 0xbbdf6a473e4be7b7U,
  0x3e29ad963efdedfbU, 0xbdcbfcadbd7afbedU, 0x3da09e933d06b679U, 0x3f09e2623c623b62U,
  0xbee7668cbec1b74cU, 0xbead09dabea2c325U, 0xbf48cb9e3e73d617U, 0x3ebb42dbbf109f99U,
  0xbf1ee74a3d18f2fcU, 0x3e908aaabe9d0578U, 0x3e4dfb4abf40f184U, 0xbf2e9cca3e12067eU,
  0xbf2d1684be83002aU, 0x3ec7cb0cbe6dbc87U, 0xbeb838dfbe7684caU, 0xbf1c5648be1ca98dU,
  0xbe8e6421be6acb95U, 0xbeabcdc8bf531bc2U, 0xbd495dffbf14add0U, 0xbeb90542beb20bf5U,
  0x3dab8c663efca99bU, 0xbc8a3d45bdc4840dU, 0x3e9593473c28b75dU, 0x3bd7a01c3d9792ffU,
  0x3cde241a3b4cdb7eU, 0x3acc10fd3f2e2425U, 0x3c1860583da62c59U, 0xbdad3b963e5c4072U,
  0x3d5c947b3e1ba631U, 0xba4522aa3ee474ccU, 0x3f021a8c3ece3933U, 0xbd06c264be0fb923U,
  0xbe389d7a3f12fb0fU, 0xbe8a17b93d65b087U, 0x3c546891beaf853bU, 0xbbfef804bd5616cdU,
  0x3b986cbdbcefd33fU, 0x3e87e0663da789bfU, 0x3e927bad3ede56ceU, 0xbc37c3553e15bcc6U,
  0xbe826c873e7478a2U, 0xbc02c919bc581328U, 0x3e7d3edcbdddf649U, 0x3e91d910bdd86eb2U,
  0xbdb8940ebda7cfb5U, 0x3f0d0a103d3a3a45U, 0xbd48d478bcd53639U, 0xbd6b2387bd5d4736U,
  0xbd809f27ba3a9a33U, 0xbe406401bdbe7da3U, 0x3ef1e775be672263U, 0xbde7fa66bde6ed2aU,
  0xbd4ed486bdd049b7U, 0xbd9800dc3e678cadU, 0x3d149edc3daffb70U, 0x3d5c3002bdfc1e40U,
  0xbe462cd43e416964U, 0xbd1faa04be49317bU, 0x3ebddb26bf1afeedU, 0x3c7ff043bc29d41fU,
  0xbf036a70bd563309U, 0xbbf8cfd8bd031acdU, 0xbdc03aa4bce4bda8U, 0x3e49b77c3e2df4a3U,
  0x3d399770be07d9ffU, 0x3eb0d749bf01af86U, 0x3c480dfc3eaab5f7U, 0xbe83e8ebbd65ae8eU,
  0xbe9e81393d4da972U, 0xbe84942e3e49184dU, 0x3e789639bdfefcfcU, 0xbd92a270be9e3831U,
  0xbb5d28ee3d3750f1U, 0x3b45123cbd23dbf9U, 0x3e6da0d6bda2b663U, 0x3e7b99b4be2516b8U,
  0xbd2d9439bd23edbcU, 0xbb026ceebe60e1bfU, 0xbd10abeb3b826590U, 0x3d1aca88be9ad83cU,
  0xbd29ad99be6995eeU, 0xbf0706d3bdd03deeU, 0x3d520d1ebef0f485U, 0xbdc742ecbd979df5U,
  0x3d586607bbd302ccU, 0x3d2be0f4be353d88U, 0x3eccc2a83dec075eU, 0xbf032b893cc3452fU,
  0x3d8f948fbea15959U, 0xbe437874bb3a0733U, 0x3c86f272bc12876aU, 0x3ec9ea113dd18de0U,
  0x3c70db50be77d6f8U, 0x3d384765bd9aefb5U, 0xbde70a1dbd3c6a73U, 0xbc4b6c463c22dcc6U,
  0xbd96ee1ebdb863bdU, 0x3ef604e13cad97dcU, 0x3dadc3e83f04a96dU, 0x3d5b28f8bbcb09dfU,
  0xbe1c2f2b3d75c548U, 0xbe1407c0bdcb2c0aU, 0xbe8a5ecabeb11253U, 0x3c24764ebba951deU,
  0x3eae4880be61f341U, 0xbdef49e3bd1f36aaU, 0xbd78fdca3d63589eU, 0xbe7c2751bcc00e42U,
  0x3d90d62e3d911d16U, 0xbeb57041bdc82ac3U, 0xbda908a2bb9411bcU, 0x3d25905c3cefee23U,
  0x3ccf900a3cc776a3U, 0x3c85170b3db4bc1aU, 0xbe5206a73e7ee788U, 0x3a7f2fe23e819650U,
  0x3d0aede2be1886dbU, 0x3d245365bdae74fbU, 0xbedf6a22bd3ad4f2U, 0x3cd929cabc0e43c3U,
  0x3dcb37c83dfc2cfeU, 0x3e924d15be0eff45U, 0xbd09eb92bbe2e622U, 0xbeb2eae1be6396d1U,
  0x3de6f969bc9047d2U, 0xbcb4218ebddd65c6U, 0xbd99d6a035676a80U, 0xbd92e40abe698a73U,
  0xbd444920bd8aaf8dU, 0xbeb6be173dc2a4e6U, 0x3d3e75f9bece2fe4U, 0x3e667e423e26ec59U,
  0x3dee1705be2a05d8U, 0x3eb418c1bcdef863U, 0xbd5b45c23e93d9adU, 0x3c8eaa7c3e6c14e3U,
  0xbee04bab3e65d689U, 0x3d827d223de1e759U, 0x3cc55d8cbdf038dbU, 0xbcef668abd76c71aU,
  0xbdcd9c5bbd09609eU, 0x3ef731073d2eb0afU, 0xbce82740bd0d84dcU, 0xbd9c4aeabd9aff1cU,
  0xbd2aec4a3d4e82dfU, 0xbe2f637abe061c7fU, 0x3eea4355bea08bdbU, 0xbdced5f2be867112U,
  0x3c0bcaa53aa2e33eU, 0xbe50b027bcbc6581U, 0xbe962c2fbbd6ab0cU, 0x3cef267fbecb794cU,
  0xbd03ca80bb5fa44eU, 0x3c89bf6d3d4a66dcU, 0x3c96670bbec91fb7U, 0xbe8f1c573eb1270eU,
  0xbefe83f23e820917U, 0xba799a623ea60752U, 0x3d8767843d8baf46U, 0x3eee3f1e3f030da0U,
  0x3f080df53eaff827U, 0x3e2e75c0bf00b5e8U, 0x3d54bfe33dd3821bU, 0xbeb56aa43e654d8fU,
  0xbe53f7af3e1b7bfdU, 0x3d1d41efbe761911U, 0x3ed4da163dc0fb56U, 0xbf3b0f73bd21a83fU,
  0xbdce6625be0285faU, 0xbe5092463d9cb870U, 0x3cc08cf3bce9bd25U, 0x3ec3e8c53e738d3bU,
  0xbda9c93ebe148e6cU, 0x3aca2e4d3d7548baU, 0x3daad53dbb328294U, 0xbca754453daf08a2U,
  0xbd4e84b53e5ffb09U, 0x3e5a2938bdb315f5U, 0xbe05a3df3eefc10bU, 0xbe862c3dbd97fbc2U,
  0xbd3f48f5bd2d881aU, 0xbd8412743df92612U, 0x3e2d11b13e02bbecU, 0xbc5b12afbe08a814U,
  0xbeac77883e977226U, 0x3c114b2fbe24ec2eU, 0x3edaff4ebf06648fU, 0x3e227309bde40ca7U,
  0xbee8dabdbd7ce32bU, 0x3d8d82c5be034a45U, 0xbdf323b4bd411d04U, 0x3b84b67bbd8a420cU,
  0xbd7e11ecbe369dc4U, 0xbe55540fbef97e40U, 0x3de33b33be821b59U, 0xbe59c1a5be3b5384U,
  0xbe96211a3d2b55a0U, 0xbe7810343e8385c7U, 0x3ec612c2bd7ee168U, 0xbf2697d1be9a48a7U,
  0x3c9fa764be04946fU, 0xbd93deaa3d6d7f60U, 0x3d99e7e03b0001e6U, 0x3ec14f7fbe661a23U,
  0xbb361415be468f62U, 0xbcc7db73be52ee77U, 0x3d004b26bb827fdeU, 0xbd5eebdbbe9c54aaU,
  0xbdf02e8ebd9e0684U, 0xbeadf7a8bda8e9a0U, 0xbe4bcda3be8c91b4U, 0xbd981cf1bc9e5f7bU,
  0x3cf0eeb1bdb7a3b0U, 0xbe55292bbceb9df3U, 0xbecac86bbc3f7164U, 0x3d04de30be7c667fU,
  0x3d5e02a2bc94ba78U, 0x3c4557f23be409d7U, 0x3a4c26cbbe034ae1U, 0xbecc517e3e86a5a2U,
  0xbde9a4c13eaf0904U, 0xbcd5c9673eacded6U, 0xbcf446563e1cdf51U, 0x3f03d2c03f0649eaU,
  0x3f082ecd3e9a3638U, 0x3d0e666fbe29ffc9U, 0x3da46943bd2d37f1U, 0xbd45f54f3e72f09fU,
  0x3cab53963f08b217U, 0xbca442cfbb4bc3a6U, 0x3df4651d3b1a5db4U, 0x3b0fd9d2bdaa69e7U,
  0xbcffbdbdbb9f1c80U, 0x3b6efbc93f15533cU, 0x3993deecbd8a75beU, 0xbc03bd6c3f7c86b4U,
  0x3c05817a3f205eb0U, 0x3a4e5c3d3ec25a26U, 0x3ed816663ec6f11aU, 0x3ebbb29e3ef59a86U,
  0x3eb85dd83f15767aU, 0x3e348146bb9388f8U, 0x3c5d4c703e289612U, 0xba9d8b723d8a9be2U,
  0x3e3f6edbbe732d38U, 0x3ecc7bd0bda76d1fU, 0xbeff3a7abad8a3d1U, 0x3d0225403ead12b4U,
  0xbec40e6b3eb63c2fU, 0x3ea1c3e9bda08c64U, 0xbd60ca20be313908U, 0xbef05cbcbd9fc9cbU,
  0xbe0baed0bb5bfec1U, 0x3db5bf1a3da2ea2cU, 0xbcdb1785388f7554U, 0xbe1185adbd3a8c4fU,
  0xbd3e8cfebd741984U, 0xbe4b6d3dbe13ddbaU, 0x3ee06589be86f069U, 0xbdbd250dbe4f13d0U,
  0x3e12e8293ecc2434U, 0xbca070f1bd9068dfU, 0x3e91e3bd3c5d6fc4U, 0xbc2177c53da15224U,
  0x3d7261243ba68270U, 0x395388a03f200bbbU, 0x3be227023da519c3U, 0x3ccb26f23dc7f728U,
  0x3cf0624d3dd4f163U, 0x3b3ff1453ecdbe2cU, 0x3f0334c63eccc9c8U, 0x3e2ac7a83ccb44fbU,
  0x3df4e1583f0c220cU, 0xbe8d1ef03d841d0aU, 0x3d0b918bbecc5d46U, 0xbc073e2fbd2137c2U,
  0x3e1bd123bba4fc81U, 0x3ebc37593eb7025bU, 0x3e0b03173cb535f5U, 0x3e47a2ec3e3e1704U,
  0x3ca8e77a3c89395eU, 0x3e8230a53ea52be3U, 0x3b133b733d8e02f0U, 0xbc05e5ed3e4c92cdU,
  0x3f1123953eca27b7U, 0x3eb7170c3f0091d9U, 0xc045f2f6c0308ff0U, 0x3f24ee90bea8bd44U,
  0xbf5c2e933f9cd2a3U, 0xbf99c9103f405d40U, 0x3eac9a8e3f7ef984U, 0x3e1f3c983f421588U,
  0x3eac52583f58f47fU, 0xc0b4128ec0c49ec6U, 0x3e8117313f928c65U, 0x3f378b9c3e0c6a88U,
  0xc070570fc01fb4dfU, 0xc0de36f4c09e386fU, 0x3ee3f4f2bd850fc5U, 0x3f16b92e3f45215eU,
  0x3f126e873f7ceb1bU, 0x3f9d94ed3e72a82eU, 0xc0563a99401b8c03U, 0x3d5d93ebc1017c99U,
  0x40453005c04e17d2U, 0x3ff32b8e3f5ddc7fU, 0x3e68438ec0cc5f91U, 0x3f1ee3ddc079d901U,
  0xc029477ebf855bd4U, 0xc044aa1b3f56b34eU, 0x3fa943993fe82c96U, 0xc0870edac083dae9U,
  0x400a7a353fb1c784U, 0xc0606cf5bfd8a84eU, 0x3f0ab8393f927e46U, 0xbfaec351c06cb677U,
  0xc0fca5413f315729U, 0x40104cabc08a9dacU, 0x3f8b896ac0bb39bbU, 0xc0c56bf63f40bc56U,
  0xc05b654ebf903a99U, 0x3f516057c0b21e30U, 0x3e10f5273eaa0905U, 0x3ec034c5c04bae56U,
  0x3f15c5f2c14847c4U, 0x3f30afa13f05ad12U, 0xc061b5873e8397d1U, 0x3f3169d73f2bb67cU,
  0xc0c84723c104f6fcU, 0x3f87998a3f53c1e3U, 0xc17b10afc092c9e5U, 0xc12bf3973f53d00dU,
  0x3e9c9c3abf24316dU, 0x3e125ec1bfde31f8U, 0x3f67df0a3f929aadU,
};


ai_handle g_model_maintenance_weights_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(s_model_maintenance_weights_array_u64),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};

